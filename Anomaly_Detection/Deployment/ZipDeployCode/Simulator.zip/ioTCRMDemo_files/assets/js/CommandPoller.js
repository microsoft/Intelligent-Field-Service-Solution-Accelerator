﻿function CommandPoller(viewModel, timeout) {
    this.lives = true;
    this.viewModel = viewModel;
    this.timeout = setTimeout(this._start.bind(this), timeout);
}

// Waits the time defined between iterations to execute.
function IterationCommandPoller(viewModel) {
    return new CommandPoller(viewModel, 1000);
}

// Waits the time defined before executing for the first time.
function StartCommandPoller(viewModel) {
    return new CommandPoller(viewModel, 5000);
}

CommandPoller.prototype._start = function () {
    this.timeout = null;
    if (this.lives) {
        this.viewModel.pollForCommands(this._onSuccess, this._onComplete.bind(this), this._onError);
    }
};

CommandPoller.prototype._onSuccess = function (commandName, parameters) {
    view.onCommand(commandName, parameters);
};

CommandPoller.prototype._onComplete = function () {
    if (this.lives) {
        view.setCurrentPoller(new IterationCommandPoller(this.viewModel));
    }
};

CommandPoller.prototype._onError = function (errorMessage) {
    view.onError(errorMessage);
};

CommandPoller.prototype.kill = function () {
    this.lives = false;
    if (this.timeout) {
        clearTimeout(this.timeout);
    }
};