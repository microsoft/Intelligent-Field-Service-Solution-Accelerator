﻿var connectionModal = {

    _CONNECTION_ERROR: {
        CREDENTIALS: "CREDENTIALS",
        SERVER: "SERVER"
    },
    _CONSTANTS:  {
        KEYCODES: {
            Backspace: 8,
            Tab: 9,
            Escape: 27,
            Space: 32
        }
    },
    init: function () {
        this._initFields();
        this._closeButton.on("click", this._clean.bind(this));
        var _this = this;
        this._saveButton.on("click", this._testConnection.bind(this));
        this._modal.on("keydown", this._trapFocusInsideModal.bind(this));
        this._credentialsErrorMessage.hide();
        this._serverConnectionErrorMessage.hide();
        this._setNavigatorLabel(this.NAV_STATUS.FAILED);

        // Set the default connection values
        this._setValuesFromViewModel();
        // Try the default connection.
        this._testConnection();
    },

    _initFields: function () {
        this._modal = $('#connectionConfig');
        this._navLinkConnection = $('#connectionNavLink');
        // Messages
        this._credentialsErrorMessage = $("#credentialsErrorMessage");
        this._serverConnectionErrorMessage = $("#serverConnectionErrorMessage");

        this._navLabelSuccess = $("#successConnectionNavLabel");
        this._navLabelFailure = $("#failedConnectionNavLabel");
        this._navLabelPending = $("#pendingConnectionNavLabel");
        this._navLabelArray = [this._navLabelPending, this._navLabelFailure, this._navLabelSuccess];
        this.NAV_STATUS = {"PENDING" : this._navLabelPending, "FAILED" : this._navLabelFailure, "SUCCESS" : this._navLabelSuccess};

        // Input fields
        this._hostElem = $("#hostInput");
        this._policyNameElem = $("#policyNameInput");
        this._keyElem = $("#keyInput");
        this._pushingRateElem = $("#pushingRateInput");
        this._fields = [this._hostElem, this._policyNameElem, this._keyElem, this._pushingRateElem];
        // Buttons
        this._testingButton = $("#testingButton");
        this._closeButton = $("#closeModalButton");
        this._saveButton = $("#configButton");
    },

    _hide: function () {
        this._modal.modal('hide');
        this._clean();
    },

    _clean: function () {
        this._testing(false);
        this._setValuesFromViewModel();
        var _this = this;
        setTimeout(function () {
            _this._navLinkConnection.focus();
        });
    },
    _trapFocusInsideModal: function (event) {
        //Key code 9 means if user press tab key.
        if (event.keyCode === this._CONSTANTS.KEYCODES.Tab) {
            var $modalActionableElements = this._modal.find('a[href], area[href], input:not([disabled]), ' +
                'select:not([disabled]), textarea:not([disabled]), button:not([disabled]), ' +
                'iframe, object, embed, *[tabindex], *[contenteditable]');
            if (!event.shiftKey && ($(document.activeElement)[0] === $modalActionableElements.last()[0])) {
                $modalActionableElements.first().focus();
                event.preventDefault();
            } else if (event.shiftKey && $(document.activeElement)[0] === $modalActionableElements.first()[0]) {
                $modalActionableElements.last().focus();
                event.preventDefault();
            }
        }
    },
    _setValuesFromViewModel: function () {
        var connection = viewModel.getConnection();
        if (!connection) {
            connection = DefaultConnection;
        }
        this._hostElem.val(connection.getHost());
        this._policyNameElem.val(connection.getPolicyName());
        this._keyElem.val(connection.getKey());
        this._pushingRateElem.val(connection.getPushingRate());
    },

    _testConnection: function () {
        this._testing(true);
        this._setConnection();
        viewModel.testConnection(this._onCredentialSuccess.bind(this), this._onCredentialFailure.bind(this),
            this._onServerFailure.bind(this));
    },

    _setConnection: function () {
        var connection = new Connection(this._hostElem.val(), this._policyNameElem.val(), this._keyElem.val(), this._pushingRateElem.val());
        viewModel.setConnection(connection);
    },

    _onCredentialSuccess: function () {
        this._hasErrors(false);
        this._hide();

        // Save the connection information in a cookie.
        var connection = viewModel.getConnection();
        cookieManager.setCookie(cookieManager.HOST, connection.getHost());
        cookieManager.setCookie(cookieManager.POLICY, connection.getPolicyName());
        cookieManager.setCookie(cookieManager.KEY, connection.getKey());
        cookieManager.setCookie(cookieManager.PUSHING_RATE, connection.getPushingRate());
        view.connectionWasSet();
    },

    _onCredentialFailure: function () {
        this._hasErrors(this._CONNECTION_ERROR.CREDENTIALS);
        this._testing(false);
        view.connectionFailed();
    },

    _onServerFailure: function () {
        this._hasErrors(this._CONNECTION_ERROR.SERVER);
        this._testing(false);
        view.connectionFailed();
    },

    _hasErrors: function (error) {
        var _this = this;
        this._fields.forEach(function (field) {
            if (error) {
                field.parent().addClass("has-error");
            } else {
                field.parent().removeClass("has-error");
            }
        });
        if (error) {
            this._setNavigatorLabel(this.NAV_STATUS.FAILED);
            if (error === this._CONNECTION_ERROR.CREDENTIALS) {
                this._showAlert(this._credentialsErrorMessage);
            } else if (error === this._CONNECTION_ERROR.SERVER) {
                this._showAlert(this._serverConnectionErrorMessage);
            }
        } else {
            this._setNavigatorLabel(this.NAV_STATUS.SUCCESS);
        }
    },

    _setNavigatorLabel: function (NAV_STATUS_VALUE) {
        this._navLabelArray.forEach(function (label) {
            label.hide();
        });
        NAV_STATUS_VALUE.show();
    },

    _showAlert: function (alert) {
        alert.fadeIn();
        setTimeout(function () {
            alert.fadeOut();
        }, 5000);
    },

    _testing: function (testing) {
        var _this = this;
        if (testing) {
            this._setNavigatorLabel(this.NAV_STATUS.PENDING);
            _this._testingButton.show();
            _this._saveButton.hide();
        } else {
            _this._testingButton.hide();
            _this._saveButton.show();
        }
    },
};