﻿function MessageDisplayContext() {
    this.lastMessage = undefined;
    this.lastMessageTypedText = "";
    // messageHistoryQueue contains the history of messages received that have been throught the logging phase.
    this.messageHistoryQueue = [];
    // LoggingQueue contains the messages that have arrived and need to be logged.
    this.loggingQueue = [];
}

MessageDisplayContext.prototype.logMessage = function (message) {
    this.loggingQueue.push(message);
};

MessageDisplayContext.prototype._loadLastMessage = function () {
    if (this.lastMessage == undefined || this.lastMessage === this.lastMessageTypedText) {
        // There is no previous message, or it has finished, need to load a new message.
        if (this.lastMessage === this.lastMessageTypedText) {
            // If it is a message that was finished, add it to the history.
            this.messageHistoryQueue.unshift(this.lastMessage);
        }
        // To avoid stacking messages when they are received faster than the typing , we will only type the last
        // one available on the queue, and for the rest, we will skip typing and move them to history directly.
        while (this.loggingQueue.length > 1) {
            this.messageHistoryQueue.unshift(this.loggingQueue.shift());
        }
        this.lastMessage = this.loggingQueue.shift();
        this.lastMessageTypedText = "";
    }
};

// Executes one instance of the typing effect. It will either add a character to the message that is being typed,
// or load a new message once the typing for that line is complete. 
MessageDisplayContext.prototype.type = function () {
    this._loadLastMessage();
    if (this.lastMessage) {
        this.lastMessageTypedText = this.lastMessage.substr(0, this.lastMessageTypedText.length + 1);
    }
};

// Checks wether there is more typing to be done. Return false only if the current message has finished typing and there
// are no messages left on the queue waiting to be typed.
MessageDisplayContext.prototype.hasTypingFinished = function () {
    return this.lastMessage == undefined && this.loggingQueue.length == 0;
};

// Returns the text we want to be shown in the MessageDisplay window. In this case, the current typed text, and 
// in a new line each of the older messages.
MessageDisplayContext.prototype.getText = function () {
    return (this.lastMessageTypedText ? this.lastMessageTypedText + "\n" : "") + this.messageHistoryQueue.join("\n");
};

MessageDisplayContext.prototype.save = function () {
    if (this.lastMessage) {
        // Moving typed message to the history log.
        this.messageHistoryQueue.unshift(this.lastMessage);
    }
    this.lastMessage = undefined;
    this.lastMessageTypedText = "";
    // Adding all messages remaining to be typed to the history log.
    while (this.loggingQueue.length > 0) {
        this.messageHistoryQueue.unshift(this.loggingQueue.shift());
    }
};
